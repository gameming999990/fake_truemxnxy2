const express = require('express');
const app = express();
const fs = require('fs');

app.get('/onUserVisit', (req, res) => {
  const visitCountFilePath = 'visit_count.txt';
  let currentVisitCount = 0;

  try {
    currentVisitCount = parseInt(fs.readFileSync(visitCountFilePath, 'utf-8')) || 0;
  } catch (error) {
    console.error('Error reading visit count file:', error);
  }

  currentVisitCount++;

  try {
    fs.writeFileSync(visitCountFilePath, currentVisitCount.toString(), 'utf-8');
    console.log('Visit count successfully updated:', currentVisitCount);
  } catch (error) {
    console.error('Error writing visit count file:', error);
  }

  // ส่งข้อมูลกลับไปที่ client
  res.json({ visitCount: currentVisitCount });
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});