
function onUserVisit() {
  

  if (currentAmount <= maxAmount) {
    amountTotalElement.innerText = currentAmount.toFixed(2) + ' / ' + maxAmount.toFixed(2) + ' ฿';


    var ulElement = document.querySelector('.collection');
    var liElement = document.createElement('li');
    
    var currentDate = new Date();
    var buddhistYear = currentDate.getFullYear() + 543;

    var formattedYear = buddhistYear.toString().slice(-2);
    var formattedTime = currentDate.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
    var formattedDate = (
      currentDate.getDate().toString().padStart(2, '0') + '/' +
      (currentDate.getMonth() + 1).toString().padStart(2, '0') + '/' +
      formattedYear
    );

    liElement.className = 'collection-item borderless but-bottom';
    liElement.innerHTML = `
      <div class="row margin-0">
        <div class="col s7">
          <p id="name" class="left margin-2 font-prompt font-17 font-truncate">บิดครับ ***</p>
        </div>
        <div class="col s5">
          <p id="amount" class="right margin-2 font-prompt font-17 grey-text text-darken-1">500.00 ฿</p>
        </div>
        <div class="col s7">
          <p id="mobile" class="left margin-2 font-thonburi font-12 grey-text text-darken-1">055-xxx-5555</p>
        </div>
        <div class="col s5">
          <p id="date_time" class="right margin-2 font-thonburi font-10 grey-text text-darken-1">${formattedDate} เวลา ${formattedTime}</p>
        </div>
      </div>
    `;
    ulElement.appendChild(liElement);
  }
}

onUserVisit();