
document.getElementById("voucher_detail").addEventListener("click", function() {
    window.open("info", "_blank");
});
 document.getElementById('footer_button').addEventListener('click', function() {
    window.location.href = 'accept';
  });
const mobileField = document.querySelector('#mobile_txtfield');

const mobileErrorMsg = document.querySelector('#mobile_txtfield_msg');

const footerButton = document.querySelector('#footer_button');


mobileField.addEventListener('input', () => {
  
  if (mobileField.value.length === 12) {
    
    footerButton.classList.remove('disabled');
    
    footerButton.classList.add('green');
  } else {
    
    footerButton.classList.add('disabled');
    
    footerButton.classList.remove('green');
  }
});

footerButton.addEventListener('click', () => {
  
  if (mobileField.validity.valid) {
    
    document.getElementById('gift_image').style.display='block';
  } else {

    mobileField.classList.add('invalid');
    mobileErrorMsg.setAttribute('data-error', 'กรุณากรอกเบอร์โทรศัพท์ให้ครบถ้วน');
  }
});

var currentCount = 0;
var totalCount = 2;


var amountReceiverElement = document.getElementById('amount_receiver');

// แสดงค่าเริ่มต้น
amountReceiverElement.innerText = currentCount + ' / ' + totalCount + ' คน';

// ฟังก์ชัน ตกลง
function onAgree() {
  // เพิ่มค่า
  currentCount++;

      // ตรวจสอบว่าค่าไม่เกิน
  if (currentCount <= totalCount) {
     // แสดงค่าใหม่
    amountReceiverElement.innerText = currentCount + ' / ' + totalCount + ' คน';
  } else {
    // ถ้าเกิน
    currentCount--;
  }
}