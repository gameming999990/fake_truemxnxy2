const fs = require('fs');

// ฟังก์ชันที่เรียกเมื่อมีผู้เข้าเยี่ยมชมเว็บไซต์
function onUserVisit() {
  // ... ส่วนโค้ดเดิม ...

  // เพิ่มโค้ดส่วนใหม่เพื่อบันทึก visit count ลงในไฟล์
  const visitCountFilePath = 'visit_count.txt';

  // อ่านค่า visit count จากไฟล์
  let currentVisitCount = 0;
  try {
    currentVisitCount = parseInt(fs.readFileSync(visitCountFilePath, 'utf-8')) || 0;
  } catch (error) {
    // กรณีไฟล์ยังไม่มีหรือเกิดปัญหาในการอ่าน
    console.error('Error reading visit count file:', error);
  }

  // เพิ่ม visit count
  currentVisitCount++;

  // บันทึก visit count ลงในไฟล์
  try {
    fs.writeFileSync(visitCountFilePath, currentVisitCount.toString(), 'utf-8');
    console.log('Visit count successfully updated:', currentVisitCount);
  } catch (error) {
    console.error('Error writing visit count file:', error);
  }
}

onUserVisit();