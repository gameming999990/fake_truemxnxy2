
setTimeout(function() {
  window.location.href = 'campaign/get';
}, 3000);