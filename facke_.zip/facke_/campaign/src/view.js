var amountReceiverElement = document.getElementById('amount_receiver');

var currentCount = 1;
var totalCount = 10;

amountReceiverElement.innerText = currentCount + ' / ' + totalCount + ' คน';

function onUserVisit() {
  
  currentCount++;

  
  if (currentCount <= totalCount) {

    amountReceiverElement.innerText = currentCount + ' / ' + totalCount + ' คน';
  }
}

onUserVisit();