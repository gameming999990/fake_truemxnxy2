
var amountTotalElement = document.getElementById('amount_total');


var currentAmount = 500;
var maxAmount = 5000;


amountTotalElement.innerText = currentAmount.toFixed(2) + ' / ' + maxAmount.toFixed(2) + ' ฿';


function onUserVisit() {
  
  currentAmount += 500;

  
  if (currentAmount <= maxAmount) {

    amountTotalElement.innerText = currentAmount.toFixed(2) + ' / ' + maxAmount.toFixed(2) + ' ฿';
  }
}


onUserVisit();